using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public PowerUpInfo[] powerUps;

    private PowerUpInfo powerUpInfo;

    void Start()
    {
        if (powerUps.Length > 0)
        {
            powerUpInfo = powerUps[Random.Range(1, powerUps.Length)];
        }

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        PlayerStats stats = other.GetComponent<PlayerStats>();
        if(stats != null)
        {
            stats.OnApplyPowerUp(powerUpInfo);
        }
    }
}
