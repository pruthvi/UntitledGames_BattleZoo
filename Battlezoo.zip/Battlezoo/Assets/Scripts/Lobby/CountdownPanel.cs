﻿using UnityEngine.UI;
using UnityEngine;

namespace UntitledGames.Lobby
{
    public class CountdownPanel : MonoBehaviour
    {
        public Text UIText;
    }
}
